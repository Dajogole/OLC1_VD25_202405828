package ast;

public enum OperadorRelacional {
    IGUAL,
    DIFERENTE,
    MENOR,
    MAYOR,
    MENOR_IGUAL,
    MAYOR_IGUAL
}