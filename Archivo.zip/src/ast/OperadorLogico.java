package ast;
public enum OperadorLogico {
    AND,
    OR,
    XOR,
    NOT
}
