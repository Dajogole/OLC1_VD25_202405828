package semantic;

public enum CategoriaSimbolo {
    VARIABLE,
    CONSTANTE
}