package reports;

public enum ErrorTipo {
    LEXICO,
    SINTACTICO,
    SEMANTICO
}