import ui.JavaUSACApp;

public class Main {
    public static void main(String[] args) {
        JavaUSACApp.launch();
    }
}
